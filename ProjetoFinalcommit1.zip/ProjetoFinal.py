# -*- coding: utf-8 -*-
"""
Created on Tue Oct 23 15:05:43 2018

@author: Victor Jurdi & Victor Habib

Projeto Final de Design de Software


"""

from flask import Flask, render_template, request
app = Flask(__name__)

itens=[]


from firebase import firebase
firebase = firebase.FirebaseApplication('https://projetofinal-dessoft.firebaseio.com/',None)
if firebase.get('/',None) is None:
    arquivo_firebase = {}
else:
    arquivo_firebase=firebase.get('/',None)

for e in arquivo_firebase['Achados_Perdidos']:
    itens.append(e)
    

    
@app.route("/", methods=['POST', 'GET'])
def index():
    return render_template('index.html')
    




@app.route("/achados_perdidos", methods=['POST', 'GET'])
def Achados_Perdidos():
    mensagem_erro_nome= ''
    mensagem_erro_item = ''
    mensagem_erro_data = ''
    mensagem_erro_lugar = ''
        

    if request.method == 'POST':
        nome = request.form['nome']
        item = request.form['item']
        data = request.form['data']
        lugar = request.form['lugar']
        
        novo_item = {
            'id':len(itens),
            'nome': nome,
            'item': item,
            'data': data,
            'lugar': lugar,
            'encontrado': False,
        }
        tem_erro = False
        if len(nome)==0:
            mensagem_erro_nome= 'Favor insira o nome do proprietário, caso não saiba digite n'
            tem_erro=True
        if len(item)==0:
            mensagem_erro_item='Favor digite qual item foi encontrado'
        if len(data) == 0:
            mensagem_erro_data = 'Favor inserir uma data'
            tem_erro = True
        if len(lugar)==0:
            mensagem_erro_lugar = 'Lugar não pode ser vazio'
            tem_erro = True
        if not tem_erro:
            itens.append(novo_item)
            arquivo_firebase['Achados_Perdidos']=itens
            firebase.patch('https://projetofinal-dessoft.firebaseio.com/', arquivo_firebase )

        
    return render_template('achados_perdidos.html', itens=itens,
                           mensagem_erro_nome=mensagem_erro_nome,
                           mensagem_erro_item=mensagem_erro_item,
                           mensagem_erro_data=mensagem_erro_data,
                           mensagem_erro_lugar=mensagem_erro_lugar)
    
    
@app.route("/salas/<salas_id>", methods=['POST', 'GET'])
def Mapa(salas_id):
    mensagem_erro_sala=''
    
    if request.method == 'POST':
        planta_sala=''
        sala = request.form['sala']

        erro=False
        if len(sala)==0:
            mensagem_erro_sala='Escolha uma sala'
            erro=True
        elif sala not in arquivo_firebase['Salas']:
            mensagem_erro_sala='Esta sala não existe'
            erro=True
        for andar in arquivo_firebase['Salas']:
            for salaa in arquivo_firebase['Salas'][andar]:
                for name in arquivo_firebase['Salas'][andar][salaa]
                    if sala == arquivo_firebase['Salas'][andar][salaa]['img']:
                        planta_sala=arquivo_firebase['Salas'][andar][salaa]['img']
        
            
    return render_template('Salas.html', itens=itens,mensagem_erro_sala=mensagem_erro_sala,planta_sala=planta_sala)
        
    
    
    
    
    

@app.route("/entidade/<id>")
def Entidades(id):
    ent=arquivo_firebase['Entidades']

    return render_template('entidade.html',img=ent[id]['img'],descricao=ent[id]['descriçao'])


    
app.run('0.0.0.0', 5004, False)

